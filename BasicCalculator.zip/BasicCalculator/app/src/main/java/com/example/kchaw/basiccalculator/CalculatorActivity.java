package com.example.kchaw.basiccalculator;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static java.lang.Math.sqrt;

public class CalculatorActivity extends AppCompatActivity {

    private static final String TAG = "CalculatorActivity";

    private EditText minput1;
    private EditText minput2;
    private EditText moutput;

    private Button mCalcAddButton;
    private Button mCalcSubButton;
    private Button mCalcMulButton;
    private Button mCalcDivButton;
    private Button mCalcPercentButton;
    private Button mCalcSqRootButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);

        minput1 = (EditText) findViewById(R.id.editText1);
        minput2 = (EditText) findViewById(R.id.editText2);
        moutput = (EditText) findViewById(R.id.editText3);

        mCalcAddButton = (Button) findViewById(R.id.button1);
        mCalcAddButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
// It is checked whether valid input is entered before proceeding with the calculations
                if (!isValidInput(true, true)) {
                    Toast.makeText(CalculatorActivity.this,
                            "Input Error: Operands not entered properly",
                            Toast.LENGTH_SHORT).show();
                    clear_input();
                } else {
// Addition calculation
                    double result = Double.valueOf(minput1.getText().toString()) +
                            Double.valueOf(minput2.getText().toString());
                    moutput.setText(String.format("%.03f", result));
                }
            }
        });

        mCalcSubButton = (Button) findViewById(R.id.button2);
        mCalcSubButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!isValidInput(true, true)) {
                    Toast.makeText(CalculatorActivity.this,
                            "Input Error: Operands not entered properly",
                            Toast.LENGTH_SHORT).show();
                    clear_input();
                } else {
                    // Subtraction
                    double result = Double.valueOf(minput1.getText().toString()) -
                            Double.valueOf(minput2.getText().toString());
                    moutput.setText(String.format("%.03f", result));
                }
            }
        });

        mCalcMulButton = (Button) findViewById(R.id.button3);
        mCalcMulButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!isValidInput(true, true)) {
                    Toast.makeText(CalculatorActivity.this,
                            "Input Error: Operands not entered properly",
                            Toast.LENGTH_SHORT).show();
                    clear_input();
                } else {
                    // Multiplication
                    double result = Double.valueOf(minput1.getText().toString()) *
                            Double.valueOf(minput2.getText().toString());
                    moutput.setText(String.format("%.03f", result));
                }
            }
        });

        mCalcDivButton = (Button) findViewById(R.id.button4);
        mCalcDivButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!isValidInput(true, true)) {
                    Toast.makeText(CalculatorActivity.this,
                            "Input Error: Operands not entered properly",
                            Toast.LENGTH_SHORT).show();
                    clear_input();
                } else
                    {
                        // Division. For Divide by zero, Error message is displayed
                    double result = Double.valueOf(minput1.getText().toString()) /
                            Double.valueOf(minput2.getText().toString());
                    moutput.setText(String.format("%.03f", result));
                }
            }
        });

        mCalcPercentButton = (Button) findViewById(R.id.button5);
        mCalcPercentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!isValidInput(true, false)) {
                    Toast.makeText(CalculatorActivity.this,
                            "Input Error: Operands not entered properly",
                            Toast.LENGTH_SHORT).show();
                    clear_input();
                } else {
                    // Percentage is calculated
                    double result = Double.valueOf(minput1.getText().toString()) / 100.0;
                    moutput.setText(String.format("%.03f", result));
                }
            }
        });

        mCalcSqRootButton = (Button) findViewById(R.id.button6);
        mCalcSqRootButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!isValidInput(true, false)) {
                    Toast.makeText(CalculatorActivity.this,
                            "Input Error: Operands not entered properly",
                            Toast.LENGTH_SHORT).show();
                    clear_input();
                } else {
                    // Square root calculation
                    double result = sqrt(Double.valueOf(minput1.getText().toString()));
                    moutput.setText(String.format("%.03f", result));
                }
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.d(TAG, "onStart() called");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume() called");
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(TAG, "onPause() called");
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.d(TAG, "onStop() called");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy() called");
    }

    private boolean isValidInput(boolean NeedOp1, boolean NeedOp2) {
        String operand1String = minput1.getText().toString();
        String operand2String = minput2.getText().toString();

        if (NeedOp1) {
            if (operand1String.length() == 0) {
                return false;
            } else if (Double.parseDouble(operand1String) <= 0.00) {
                return false;
            }
        }

        if (NeedOp2) {
            if (operand2String.length() == 0) {
                return false;
            } else if (Double.parseDouble(operand2String) <= 0.00) {
                return false;
            }
        }

        return true;
    }


    /**
     * Clears the input text edit boxes
     */
    private void clear_input() {
        minput1.setText("");
        minput2.setText("");
        moutput.setText("");

    }
}
